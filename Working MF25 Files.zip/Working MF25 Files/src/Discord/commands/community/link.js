import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { invitee, loginViaGoogle, linkTrade, logout } from '../../../MFClient/client.js';
import { createUser, fetchmfUserByDiscordID, deleteUsername } from '../../database/database.js'; // Ensure deleteUsername is imported
import chalk from 'chalk';

export default {
  data: new SlashCommandBuilder()
    .setName('link')
    .setDescription('Link an username bozo')
    .addStringOption(option => option
      .setName('name')
      .setDescription('Who do u want to send them to?')
      .setRequired(true)),
  async execute(interaction) {
    const userId = interaction.user.id;
    const username = interaction.options.getString('name');
    const lowerUsername = username.toLowerCase();
    const invitingEmbed = new EmbedBuilder()
      .setColor('Yellow')
      .setDescription(`A verification invite has been sent to ${lowerUsername}\nAccept it within one minute to become linked.`);
    await interaction.reply({ embeds: [invitingEmbed] });
    try {
      const login = await loginViaGoogle();
      const invite = await invitee(lowerUsername, login.auth);
      await logout(login.auth);
      const linkedEmbed = new EmbedBuilder()
        .setColor('Green')
        .setDescription(`✅ Your MADFUT username **${lowerUsername}** has successfully been linked!`);
      await interaction.followUp({ embeds: [linkedEmbed] });
      await createUser(username, userId);
    } catch (error) {
      console.log(chalk.red(error));
    }
  }
}
