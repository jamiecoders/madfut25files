import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { invitee, loginViaGoogle, otherTrade, logout } from '../../../MFClient/client.js';
import chalk from 'chalk';
import { fetchmfUserByDiscordID, getCoins, getBotTrades, getLTMPoints, removeBotTrades, getPlayerPicks, getCards } from '../../database/database.js';

export default {
  data: new SlashCommandBuilder()
    .setName('bt')
    .setDescription('[ADMIN] - Send freetrades to a user')
    .addIntegerOption(option => option
       .setName('amount')
       .setDescription('How many do you want to send?')
       .setRequired(true)
       .setMinValue(1)
       .setMaxValue(5)),
  async execute(interaction,client) {
    const userid = interaction.member.id
    const bt = await getBotTrades(userid);
    const userId = interaction.user.id;
    const lowerUsername = await fetchmfUserByDiscordID(userId);
    const amount = interaction.options.getInteger('amount')
    if (!lowerUsername) {
        interaction.reply({
          embeds: [
            {
              description: `> This account has not been linked`
            }
          ]
        });
        return
      } else if (bt + 1 <= amount) {
        interaction.reply({
          embeds: [
            {
              description: `> You Dont Have Enough Bot Trades`
            }
          ]
        })
        return;
      }
    const invitingEmbed = new EmbedBuilder()
      .setTitle('Bot Trades 2024 - sending bot trades fam')
      .setDescription(`Sent ${amount} trade to ${lowerUsername}\nThese trades expire in two minutes\n - Accept the invite from *FireFUT2*\n - Get them to do the trades`);
    await interaction.reply({ embeds: [invitingEmbed] });
        let tradesCompletedFully = 0;
        while (tradesCompletedFully < amount) {
            try {                
                const login = await loginViaGoogle();
                const invite = await invitee(lowerUsername, login.auth, '60000',);
                await otherTrade(invite.hosting, invite.roomId, login.auth);
                await logout(login.auth);
                await removeBotTrades(userId, 1);
                tradesCompletedFully++;
                const completingEmbed = new EmbedBuilder()
                    .setTitle('Bot Trades 2024 - Trade Counter')
                    .setDescription(`Sent ${amount} trade to ${lowerUsername}\n\nDone ${tradesCompletedFully}/${amount} `);
                await interaction.followUp({ embeds: [completingEmbed] });
                removeBotTrades(userid, 1);
            } catch (error) {
            console.log((error));
            }
        }
        console.log(`${tradesCompletedFully}/${amount} done with: ${lowerUsername}`)
        const finishedFreetrades = new EmbedBuilder()
        .setTitle('Bot Trades 2024 - Finished')
        .setDescription(`${lowerUsername} has finished all trades (${amount})`)
        await interaction.followUp({ embeds: [finishedFreetrades] });
    }
}