import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { fetchmfUserByDiscordID, getCoins, getBotTrades, getLTMPoints, getPlayerPicks, getCards, getTop5BotTrades } from '../../database/database.js';
import chalk from 'chalk';

export default {
    data: new SlashCommandBuilder()
        .setName('wallet')
        .setDescription('Display your MADFUT wallet'),
    async execute(interaction) {
        const userId = interaction.user.id;
        const linkedUsername = await fetchmfUserByDiscordID(userId);
        if (!linkedUsername) {
            const notLinkedEmbed = new EmbedBuilder()
                .setColor('Red')
                .setDescription('You do not have a linked account. Link one using `/link`.');
            await interaction.reply({ embeds: [notLinkedEmbed], ephemeral: true });
            return; // Stop execution if not linked
        }

        const [coins, botTrades, ltmPoints, packs, cards] = await Promise.all([
            getCoins(userId),
            getBotTrades(userId),
            getLTMPoints(userId),
        ]);

        const walletEmbed = new EmbedBuilder()
            .setColor('Green')
            .setTitle(`${interaction.user.username}'s MADFUT Wallet`) // Use username, not display name
            .setDescription('Your Wallet Overview is shown below.')
            .addFields(
                { name: 'Coins:', value: `${coins}`, inline: true },
                { name: 'Bot Trades:', value: `${botTrades}`, inline: true },
                { name: 'LTM Points:', value: `${ltmPoints}`, inline: true },
            );

        const coinsButton = new ButtonBuilder()
            .setCustomId('Coins')
            .setLabel('View Coins')
            .setStyle(ButtonStyle.Secondary);

        const botTradesButton = new ButtonBuilder()
            .setCustomId('BotTrades')
            .setLabel('View Bot Trades')
            .setStyle(ButtonStyle.Secondary);

        const buttons = new ActionRowBuilder()
            .addComponents(coinsButton, botTradesButton);

        await interaction.reply({ embeds: [walletEmbed], components: [buttons] });

        const filter = i => i.customId === 'Coins' && i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async i => {
            if (i.customId === 'Coins') {
                if (!i.deferred) {
                    await i.deferUpdate(); // Acknowledge the interaction
                }

                const coinsEmbed = new EmbedBuilder()
                    .setColor('Green')
                    .setTitle(`${interaction.user.username}'s Coins`)
                    .setDescription(`You currently have **${coins} Coins**.`);

                const goBackButton = new ButtonBuilder()
                    .setCustomId('GoBack')
                    .setLabel('Overview')
                    .setStyle(ButtonStyle.Secondary);

                const newButtons = new ActionRowBuilder()
                    .addComponents(goBackButton);

                await interaction.editReply({ embeds: [coinsEmbed], components: [newButtons], ephemeral: true }); // Follow up with the coin embed

                const goBackFilter = i => i.customId === 'GoBack' && i.user.id === interaction.user.id;
                const goBackCollector = interaction.channel.createMessageComponentCollector({ filter: goBackFilter, time: 15000 });

                goBackCollector.on('collect', async i => {
                    if (i.customId === 'GoBack') {
                        if (!i.deferred) {
                            await i.deferUpdate(); // Acknowledge the interaction
                        }
                        await interaction.editReply({ embeds: [walletEmbed], components: [buttons], ephemeral: true }); // Go back to the wallet embed
                    }
                });

                goBackCollector.on('end', collected => {
                    console.log(`Collected ${collected.size} interactions.`);
                });
            }
        });

        const botTradesFilter = i => i.customId === 'BotTrades' && i.user.id === interaction.user.id;
        const botTradesCollector = interaction.channel.createMessageComponentCollector({ filter: botTradesFilter, time: 15000 });

        botTradesCollector.on('collect', async i => {
            if (i.customId === 'BotTrades') {
                if (!i.deferred) {
                    await i.deferUpdate(); // Acknowledge the interaction
                }

                const botTradesEmbed = new EmbedBuilder()
                    .setColor('Green')
                    .setTitle(`${interaction.user.username}'s Bot Trades`)
                    .setDescription(`You currently have **${botTrades} Bot Trades**.`);

                const goBackButton = new ButtonBuilder()
                    .setCustomId('GoBack')
                    .setLabel('Overview')
                    .setStyle(ButtonStyle.Secondary);

                const newButtons = new ActionRowBuilder()
                    .addComponents(goBackButton);

                await interaction.editReply({ embeds: [botTradesEmbed], components: [newButtons], ephemeral: true }); // Follow up with the bot trades embed

                const goBackFilter = i => i.customId === 'GoBack' && i.user.id === interaction.user.id;
                const goBackCollector = interaction.channel.createMessageComponentCollector({ filter: goBackFilter, time: 15000 });

                goBackCollector.on('collect', async i => {
                    if (i.customId === 'GoBack') {
                        if (!i.deferred) {
                            await i.deferUpdate(); // Acknowledge the interaction
                        }
                        await interaction.editReply({ embeds: [walletEmbed], components: [buttons], ephemeral: true }); // Go back to the wallet embed
                    }
                });

                goBackCollector.on('end', collected => {
                    console.log(`Collected ${collected.size} interactions.`);
                });
            }
        });
    }
}