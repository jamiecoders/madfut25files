import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { fetchmfUserByDiscordID, deleteUsername } from '../../database/database.js';
import chalk from 'chalk';

export default {
  data: new SlashCommandBuilder()
    .setName('unlink')
    .setDescription('Unlink your linked MADFUT account'),
    async execute(interaction) {
        const userId = interaction.user.id;
        const hasLinkedTheirAccount = await fetchmfUserByDiscordID(userId)
        if (!hasLinkedTheirAccount) {
            const notLinkedEmbed = new EmbedBuilder()
            .setColor('Red')
            .setDescription('You do not have a linked account to unlink\nLink an account with the command: </link:1272051536620556289>')
            await interaction.reply({ embeds: [notLinkedEmbed], ephemeral: true });
            return;
        }
        const buttons = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('yes')
                .setLabel('Yes, Unlink')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('no')
                .setLabel('No, Cancel')
                .setStyle(ButtonStyle.Secondary));
        const unlinkEmbed = new EmbedBuilder()
        .setColor('Yellow')
        .setDescription('Are you sure you want to unlink your account?\nClick a button below to continue.')
        await interaction.reply({ embeds: [unlinkEmbed], ephemeral: true, components: [buttons] });
        const filter = i => i.user.id === userId;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });
            collector.on('collect', async i => {
                if (i.customId === 'yes') {
                await deleteUsername(userId);
                const successEmbed = new EmbedBuilder()
                    .setColor('Green')
                    .setDescription('✅ Your MADFUT account has successfully been unlinked!')
                await i.update({ embeds: [successEmbed], ephemeral: true, components: [] });
            } else if (i.customId === 'no') {
                const cancelEmbed = new EmbedBuilder()
                    .setColor('Blue')
                    .setDescription('You cancelled the process therefore, you havent been unlinked')
                await i.update({ embeds: [cancelEmbed], ephemeral: true, components: [] });
            }
        collector.stop();
        });
    collector.on('end', async collected => {
        if (collected.size === 0) {
            const timeoutEmbed = new EmbedBuilder()
                .setColor('Red')
                .setDescription('⛔ This interaction has timed out.\nYou were too slow, respond quicker next time')
            await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
            }
        });
    }
}