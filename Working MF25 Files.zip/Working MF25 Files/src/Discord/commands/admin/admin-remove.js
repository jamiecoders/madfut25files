import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { invitee, loginViaGoogle, otherTrade, logout } from '../../../MFClient/client.js';
import { fetchmfUserByDiscordID, getCoins, getBotTrades, getLTMPoints, getPlayerPicks, removeBotTrades, removeCoins } from '../../database/database.js';
import dotenv from'dotenv';
dotenv.config();

const ALLOWED_ROLE_IDS = process.env.perms ? process.env.perms.split(',') : [];
const ALLOWED_ROLE_IDS2 = process.env.perms2 ? process.env.perms2.split(',') : [];
const ALL_ALLOWED_ROLE_IDS = [...ALLOWED_ROLE_IDS, ...ALLOWED_ROLE_IDS2];

export default {
    data: new SlashCommandBuilder()
        .setName('admin-remove')
        .setDescription('Withdraw items from your account')
        .addUserOption(option => option.setName('user').setDescription('The user to pay to').setRequired(true))
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Type of item to withdraw')
                .addChoices(
                    { name: 'Trades', value: 'bot-trades' },
                    { name: 'Coins', value: 'coins' },
                )
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount to remove')
                .setRequired(true)),
    async execute(interaction, client) {
        const { options } = interaction;
        const amount = interaction.options.getInteger('amount');
        const type = interaction.options.getString('type');
        const targetUser = options.getUser('user');
        const userId = targetUser.id;
        const linked = await fetchmfUserByDiscordID(userId);
        const member = interaction.member;
        const hasPermission = ALL_ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
        if (!hasPermission) {
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setDescription('⛔ You do not have permission to use this command.');
    
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }
        if (!linked) {
            interaction.reply({
                embeds: [
                    {
                        description: `> This account has not been linked`
                    }
                ]
            });
            return
        } else if (amount < getBotTrades && type === 'bot-trades') {
            const embed = new EmbedBuilder()
           .setTitle('Error | Admin Remove')
           .setDescription(`> That User Has Not Got That Much Bot Trades`)
           .setFooter({ text: 'Admin Remove'});
            await interaction.reply({ embeds: [embed]});
        }  else if (amount < getCoins && type === 'coins') {
            const embed = new EmbedBuilder()
           .setTitle('Error | Admin Remove')
           .setDescription(`> That User Has Not Got That Much Coinss`)
           .setFooter({ text: 'Admin Remove'});
            await interaction.reply({ embeds: [embed]});
        }              
    
        if (type === 'bot-trades') {
            try {
                await removeBotTrades(userId, amount);
                const embed = new EmbedBuilder()
                    .setTitle('Admin Remove | Bot Trades')
                    .setDescription(`> You Have Removed ${amount} Bot Trades From ${linked}`)
                    .setFooter({ text: 'Admin Remove'});
                await interaction.reply({ embeds: [embed]});
            } catch (error) {
                const embed = new EmbedBuilder()
                    .setTitle('Error | Admin Remove')
                    .setDescription(`> ${error.message}`)
                    .setFooter({ text: 'Admin Remove'});
                await interaction.reply({ embeds: [embed]});
            }}
            if (type === 'coins') {
                try {
                    await removeCoins(userId, amount);
                    const embed = new EmbedBuilder()
                        .setTitle('Admin Remove | Coins')
                        .setDescription(`> You Have Removed ${amount} Coins From ${linked}`)
                        .setFooter({ text: 'Admin Remove'});
                    await interaction.reply({ embeds: [embed]});
                } catch (error) {
                    const embed = new EmbedBuilder()
                        .setTitle('Error | Admin Remove')
                        .setDescription(`> ${error.message}`)
                        .setFooter({ text: 'Admin Remove'});
                    await interaction.reply({ embeds: [embed]});
                }}
    }}