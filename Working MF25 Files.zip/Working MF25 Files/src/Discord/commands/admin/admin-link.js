import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { invitee, loginViaGoogle, linkTrade, logout } from '../../../MFClient/client.js';
import { createUser, fetchmfUserByDiscordID, deleteUsername } from '../../database/database.js'; // Ensure deleteUsername is imported
import chalk from 'chalk';
import dotenv from 'dotenv';
dotenv.config();

const ALLOWED_ROLE_IDS = process.env.perms ? process.env.perms.split(',') : [];
const ALLOWED_ROLE_IDS2 = process.env.perms2 ? process.env.perms2.split(',') : [];
const ALL_ALLOWED_ROLE_IDS = [...ALLOWED_ROLE_IDS, ...ALLOWED_ROLE_IDS2];

export default {
  data: new SlashCommandBuilder()
    .setName('admin-link')
    .setDescription('Link an username bozo')
    .addUserOption(option => option.setName('user').setDescription('The user to pay to').setRequired(true))
    .addStringOption(option => option
      .setName('name')
      .setDescription('Who do u want to send them to?')
      .setRequired(true)),
  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const userId = targetUser.id;
    const username = interaction.options.getString('name');
    const lowerUsername = username.toLowerCase();
    const linked = await fetchmfUserByDiscordID(userId);
    const member = interaction.member;
    const hasPermission = ALL_ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));

    if (!hasPermission) {
      const embed = new EmbedBuilder()
        .setColor('Red')
        .setDescription('⛔ You do not have permission to use this command.');
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const buttons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('yes')
          .setLabel('Yes, Unlink')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('no')
          .setLabel('No, Cancel')
          .setStyle(ButtonStyle.Secondary)
      );

    if (linked) {
      const embed = new EmbedBuilder()
        .setTitle('User Linked')
        .setDescription(`> ${username} is linked to an account.\n> Would U Like To Unlink?`);
      await interaction.reply({ embeds: [embed], ephemeral: true, components: [buttons] });

      const filter = i => i.user.id === userId;
      const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async i => {
        await i.deferUpdate(); // Acknowledge the button press

        if (i.customId === 'yes') {
          await deleteUsername(userId); // Ensure this function works
          const successEmbed = new EmbedBuilder()
            .setColor('Green')
            .setDescription('✅ Your MADFUT account has successfully been unlinked!');
          await i.editReply({ embeds: [successEmbed], components: [] });
        } else if (i.customId === 'no') {
          const cancelEmbed = new EmbedBuilder()
            .setColor('Blue')
            .setDescription('You cancelled the process; therefore, you haven\'t been unlinked.');
          await i.editReply({ embeds: [cancelEmbed], components: [] });
        }
        collector.stop();
      });

      collector.on('end', async collected => {
        if (collected.size === 0) {
          const timeoutEmbed = new EmbedBuilder()
            .setColor('Red')
            .setDescription('⛔ This interaction has timed out.\nYou were too slow, respond quicker next time.');
          await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
        }
      });

      return; // Prevent further processing
    }

    // Check if username already exists
    try {
      const existingUser = await fetchmfUserByDiscordID(userId); // Fetch user by Discord ID to see if already linked
      if (existingUser) {
        const existingEmbed = new EmbedBuilder()
          .setColor('Red')
          .setDescription(`❌ The username **${lowerUsername}** is already linked to another account.`);
        return await interaction.reply({ embeds: [existingEmbed], ephemeral: true });
      }

      const invitingEmbed = new EmbedBuilder()
        .setColor('Yellow')
        .setDescription(`A verification invite has been sent to ${lowerUsername}\nAccept it within one minute to become linked.`);
      await interaction.reply({ embeds: [invitingEmbed] });

      // Proceed to create the user
      await createUser(username, userId);
      const linkedEmbed = new EmbedBuilder()
        .setColor('Green')
        .setDescription(`✅ Your MADFUT username **${lowerUsername}** has successfully been linked!`);
      await interaction.followUp({ embeds: [linkedEmbed] });
    } catch (error) {
      if (error.code === 'SQLITE_CONSTRAINT') {
        const errorEmbed = new EmbedBuilder()
          .setColor('Red')
          .setDescription(`❌ The username **${lowerUsername}** is already taken. Please choose a different one.`);
        await interaction.followUp({ embeds: [errorEmbed] });
      } else {
        console.log(chalk.red(error));
      }
    }
  }
}
