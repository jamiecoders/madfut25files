import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { invitee, loginViaGoogle, otherTrade, logout } from '../../../MFClient/client.js';
import chalk from 'chalk';
import dotenv from'dotenv';
dotenv.config();

const ALLOWED_ROLE_IDS = process.env.perms ? process.env.perms.split(',') : [];
const ALLOWED_ROLE_IDS2 = process.env.perms2 ? process.env.perms2.split(',') : [];
const ALL_ALLOWED_ROLE_IDS = [...ALLOWED_ROLE_IDS, ...ALLOWED_ROLE_IDS2];


export default {
  data: new SlashCommandBuilder()
    .setName('freetrade')
    .setDescription('[ADMIN] - Send freetrades to a user')
    .addStringOption(option => option
      .setName('name')
      .setDescription('Who do u want to send them do?')
      .setRequired(true))
    .addIntegerOption(option => option
       .setName('amount')
       .setDescription('How many do you want to send?')
       .setRequired(true)
       .setMinValue(1)
       .setMaxValue(25)),
  async execute(interaction) {
    const member = interaction.member;
    const hasPermission = ALL_ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
    if (!hasPermission) {
        const embed = new EmbedBuilder()
            .setColor('Red')
            .setDescription('⛔ You do not have permission to use this command.');

        return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    const account = interaction.options.getString('name');
    const lowerUsername = account.toLowerCase();
    const amount = interaction.options.getInteger('amount')
    const invitingEmbed = new EmbedBuilder()
      .setTitle('FT 2025 - sending bot trades fam')
      .setDescription(`Sent ${amount} trade to ${lowerUsername}\nThese trades expire in two minutes\n - Accept the invite from *fuckkass*\n - Get them to do the trades`);
    await interaction.reply({ embeds: [invitingEmbed] });
        let tradesCompletedFully = 0;
        while (tradesCompletedFully < amount) {
            try {
                const login = await loginViaGoogle();
                const invite = await invitee(lowerUsername, login.auth, '60000', 'fuckkass');
                await otherTrade(invite.hosting, invite.roomId, login.auth);
                await logout(login.auth);
            tradesCompletedFully++;
                const completingEmbed = new EmbedBuilder()
                    .setTitle('FT 2025 - Trade Counter')
                    .setDescription(`Done ${tradesCompletedFully}/${amount} `);
                await interaction.followUp({ embeds: [completingEmbed] });
            } catch (error) {
            console.log(chalk.red(error));
            }
        }
        console.log(`${tradesCompletedFully}/${amount} done with: ${account}`)
        const finishedFreetrades = new EmbedBuilder()
        .setTitle('FT 2025 - Finished')
        .setDescription(`${account} has finished all trades (${amount})`)
        await interaction.followUp({ embeds: [finishedFreetrades] });
    }
}