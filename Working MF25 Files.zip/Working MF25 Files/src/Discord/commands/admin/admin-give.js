import { SlashCommandSubcommandBuilder, EmbedBuilder } from "discord.js";
import { fetchmfUserByDiscordID, addBotTrades, addCoins, getLTMPoints, removeBotTrades, getPlayerPicks, getCards } from '../../database/database.js';
import dotenv from'dotenv';
dotenv.config();

const ALLOWED_ROLE_IDS = process.env.perms ? process.env.perms.split(',') : [];
const ALLOWED_ROLE_IDS2 = process.env.perms2 ? process.env.perms2.split(',') : [];
const ALL_ALLOWED_ROLE_IDS = [...ALLOWED_ROLE_IDS, ...ALLOWED_ROLE_IDS2];

export default {
    admin: true,
    data: new SlashCommandSubcommandBuilder()
        .setName('admin-give')
        .setDescription('Give someone items into their wallet')
        .addUserOption(option => option.setName('user').setDescription('The user to pay to').setRequired(true))
        .addIntegerOption(option => option.setName('trades').setDescription('Number of trades to add to the user\'s wallet').setRequired(false))
        .addIntegerOption(option => option.setName('coins').setDescription('Number of coins to add to the user\'s wallet').setRequired(false)),
        async execute(interaction, client) {
            const member = interaction.member;
            const hasPermission = ALL_ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
            if (!hasPermission) {
                const embed = new EmbedBuilder()
                    .setColor('Red')
                    .setDescription('⛔ You do not have permission to use this command.');
        
                return interaction.reply({ embeds: [embed], ephemeral: true });
            }
            try {
                const { options } = interaction;
                const targetUser = options.getUser('user');
                const targetUsername = targetUser.displayName;
                const userId = targetUser.id;
                const linked = await fetchmfUserByDiscordID(userId);
                if (!linked) {
                    const embed = new EmbedBuilder()
                        .setTitle('User Not Linked')
                        .setDescription(`> ${targetUsername} is not linked to any account.`);
                    await interaction.reply({ embeds: [embed], ephemeral: true });
                    return;
                }
                const botTrades = options.getInteger('trades') || 0;
                await addBotTrades(userId, botTrades);
                const descriptionItems = [];
                if (botTrades) descriptionItems.push(`> Trades: **${formatNumber(botTrades)}**`);
                const coins = options.getInteger('coins') || 0;
                await addCoins(userId, coins);
                if (coins) descriptionItems.push(`> Coins: **${formatNumber(coins)}**`);
                const description = descriptionItems.join('\n');
                const embed = new EmbedBuilder()
                    .setTitle(`Admin Give - Successfully Paid ${targetUsername}!`)
                    .setDescription(`> You have paid the following items:\n> \n ${description}`);
                await interaction.reply({ embeds: [embed],});
            } catch (error) {
                console.error(error);
            }
        }        
};

function formatNumber(number) {
    return number.toLocaleString();
}

