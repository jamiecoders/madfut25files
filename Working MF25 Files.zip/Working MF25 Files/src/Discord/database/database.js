import sqlite3 from 'sqlite3';
const sqliteVerbose = sqlite3.verbose();
const database = new sqliteVerbose.Database("database.sqlite");

database.serialize(() => {
database.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, userId TEXT UNIQUE)`, (err) => {
    if (err) {
        console.error('Error creating users table:', err.message);
    } else {
        console.log('Users table created successfully.');
    }
});
database.run(`CREATE TABLE IF NOT EXISTS wallets (id INTEGER PRIMARY KEY AUTOINCREMENT, userId TEXT, dailySpin DATE, coins INTEGER NOT NULL DEFAULT 0, botTrades INTEGER NOT NULL DEFAULT 0, ltmPoints INTEGER NOT NULL DEFAULT 0, playerPicks INTEGER NOT NULL DEFAULT 0, cardIds TEXT, FOREIGN KEY(userId) REFERENCES users(userId))`, (err) => {
    if (err) {
        console.error('Error creating wallets table:', err.message);
    } else {
        console.log('Wallets table created successfully.');
    }
});
database.run(`CREATE TABLE IF NOT EXISTS cooldowns (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER UNIQUE, dailyspin INTEGER, weeklyclaim INTEGER, event INTEGER)`, (err) => {
    if (err) {
        console.error('Error creating cooldowns table:', err.message);
    } else {
        console.log('cooldowns table created successfully.');
    }
});
database.run(`CREATE TABLE IF NOT EXISTS promocodes (id INTEGER PRIMARY KEY AUTOINCREMENT, promoCodeName STRING, coinsRewards INTEGER, botTradesRewards INTEGER, ltmPointsRewards INTEGER, playerPickRewards INTEGER, claimedUserIds INTEGER, uses INTEGER)`, (err) => {
    if (err) {
        console.error('Error creating promocodes table:', err.message);
    } else {
        console.log('promocodes table created successfully.');
    }
    });
});

function runPromise(query, ...args) {
    if (args.length > 0) {
        return new Promise((resolve, reject)=>{
            database.prepare(query).run(args, function(err) {
                if (err) reject(err);
                resolve(this);
            });
        });
    }
    return new Promise((resolve, reject)=>{
        database.run(query, function(err) {
            if (err) reject(err);
            resolve(this);
        });
    });
}
function getPromise(obj, ...args) {
    if (typeof obj === 'string') {
        obj = database.prepare(obj);
    }
    return new Promise((resolve, reject)=>{
        obj.get(args, (err, rows)=>{
            if (err) reject(err);
            resolve(rows);
        });
    });
}
function getPromiseLB(obj, ...args) {
    if (typeof obj === 'string') {
        obj = database.prepare(obj);
    }
    return new Promise((resolve, reject) => {
        obj.all(args, (err, rows) => {
            if (err) reject(err);
            resolve(rows);
        });
    });
}
function allPromise(obj, ...args) {
    if (typeof obj === 'string') {
        obj = database.prepare(obj);
    }
    return new Promise((resolve, reject)=>{
        obj.all(args, (err, rows)=>{
            if (err) reject(err);
            resolve(rows);
        });
    });
}
async function createUser(username, userId) {
    const insertUserQuery = `INSERT INTO users (username, userId) VALUES (?, ?)`;
    const insertWalletQuery = `INSERT INTO wallets (userId, botTrades) VALUES (?, ?)`;
    return new Promise((resolve, reject) => {
        database.run(insertUserQuery, [username, userId], function(err) {
            if (err) {
                console.error('Error creating user:', err.message);
                return reject(err);
            }
            database.run(insertWalletQuery, [userId, '1'], function(err) {
                if (err) {
                    console.error('Error creating wallet for user:', err.message);
                    return reject(err);
                }
                resolve();
            });
            });
        });
    };
async function createCooldownDailyspin(userid){
    const insertCooldownsQuery = `INSERT INTO cooldowns (userid) VALUES (?)`;
    return new Promise((resolve, reject) => { 
        database.run(insertCooldownsQuery, [userid], function(err) {
            if (err) {
                console.error('Error creating cooldown id:', err.message);
                return reject(err);
            }
        });
        resolve();
    });
}

async function deleteUsername(userId) {
    const deleteUserQuery = `DELETE FROM users WHERE userId = ?`;
    return new Promise((resolve, reject) => {
        database.run(deleteUserQuery, [userId], function(err) {
            if (err) {
                console.error('Error deleting username:', err.message);
                return reject(err);
            }
            resolve();
        });
    });
}

async function createPromoCode(packRewards, coinsRewards, ltmPointsRewards, botTradesRewards, customPackTokens, promoCodeName) {
    const insertQuery = `INSERT INTO promocodes (packRewards, coinsRewards, ltmPointsRewards, customPackTokens, botTradesRewards, promoCodeName) VALUES (?, ?, ?, ?, ?, ?)`;
    return new Promise((resolve, reject) => { 
        database.run(insertQuery, [packRewards, coinsRewards, ltmPointsRewards, botTradesRewards, customPackTokens, promoCodeName], function(err) {
            if (err) {
                console.error('Error creating promocode:', err.message);
                return reject(err);
            }
        });
        resolve();
    });
}

async function fetchmfUserByDiscordID(userId) {
    const selectQuery = `SELECT username FROM users WHERE userId = ?`;
    return new Promise((resolve, reject) => {
        database.get(selectQuery, [userId], (err, row) => {
            if (err) {
                console.error('Error fetching username from userId:', err.message);
                return reject(err);
            }
            resolve(row ? row.username : null);
        });
    });
}

/*async function addPackToken(userId, customPackTokens) {
    const response = runPromise("UPDATE wallets SET customPackTokens = customPackTokens + (?) WHERE userId = (?);", customPackTokens.toString(), userId);
    return response.changes > 0;
}
async function addPremiumSpins(userId, premiumSpins) {
    const response = runPromise("UPDATE wallets SET premiumSpins = premiumSpins + (?) WHERE userId = (?);", premiumSpins.toString(), userId);
    return response.changes > 0;
}
async function addPacks(userId, packIds) {
    const response = runPromise("UPDATE wallets SET packIds = (?) WHERE userId = (?);", packIds.toString(), userId);
    return response.changes > 0;
}*/
/*async function checkIfOkglasses(userId){
    const response = await getPromise("SELECT glasses FROM cooldowns WHERE userId = (?);", userId);
    if(Date.now() - 43200000 <= response.glasses){return false}else if(Date.now() - 43200000 >= response.glasses){return true}else{return true}
}*/
/*async function getTop5ltmPoints() {
    try {
        const response = await getPromiseLB("SELECT userId, ltmPoints FROM wallets ORDER BY ltmPoints DESC LIMIT 5;");
        return response;
    } catch (error) {
        console.error("Error fetching top 5:", error);
        return null;
    }
}*/
/*async function getCustomPackTokens(user) {
    const response = await getPromise("SELECT customPackTokens FROM wallets WHERE userId = (?);", user);
    return response?.customPackTokens;  
}
async function getPacks(user) {
    const response = await getPromise("SELECT packIds FROM wallets WHERE userId = (?);", user);
    return response?.packIds;  
}*/
/*async function getPremiumSpins(user) {
    const response = await getPromise("SELECT premiumSpins FROM wallets WHERE userId = (?);", user);
    return response?.premiumSpins;  
}*/
/*async function removePackToken(userId, customPackTokens) {
    const response = runPromise("UPDATE wallets SET customPackTokens = customPackTokens - (?) WHERE userId = (?);", customPackTokens.toString(), userId);
    return response.changes > 0;
}*/

async function addCoins(userId, coins) {
    const response = runPromise("UPDATE wallets SET coins = coins + (?) WHERE userId = (?);", coins.toString(), userId);
    return response.changes > 0;
}
async function addBotTrades(userId, botTrades) {
    const response = runPromise("UPDATE wallets SET botTrades = botTrades + (?) WHERE userId = (?);", botTrades.toString(), userId);
    return response.changes > 0;
}
async function addLtmPoints(userId, ltmPoints) {
    const response = runPromise("UPDATE wallets SET ltmPoints = ltmPoints + (?) WHERE userId = (?);", ltmPoints.toString(), userId);
    return response.changes > 0;
}
async function addPlayerPicks(userId, playerPicks) {
    const response = runPromise("UPDATE wallets SET playerPicks = playerPicks + (?) WHERE userId = (?);", playerPicks.toString(), userId);
    return response.changes > 0;
}
async function addCards(userId, cardIds) {
    const response = runPromise("UPDATE wallets SET cardIds = (?) WHERE userId = (?);", cardIds.toString(), userId);
    return response.changes > 0;
}

async function addCooldownDailySpin(userId, timestamp) {
    const response = runPromise("UPDATE cooldowns SET dailyspin = (?) WHERE userId = (?);", timestamp.toString(), userId);
    return response.changes > 0;
}
async function addCooldownweeklyclaim(userId, timestamp) {
    const response = runPromise("UPDATE cooldowns SET weeklyclaim = (?) WHERE userId = (?);", timestamp.toString(), userId);
    return response.changes > 0;
}
async function addCooldownevent(userId, timestamp) {
    const response = runPromise("UPDATE cooldowns SET event = (?) WHERE userId = (?);", timestamp.toString(), userId);
    return response.changes > 0;
}

async function addClaimedPromoCodeByUserId(claimedUserIds, promoCodeName) {
    const response = runPromise("UPDATE promocodes SET claimedUserIds = (?) WHERE promoCodeName = (?);", claimedUserIds.toString(), promoCodeName);
    return response.changes > 0;
}
async function addUses(uses, promoCodeName) {
    const response = runPromise("UPDATE promocodes SET uses = (?) WHERE promoCodeName = (?);", uses.toString(), promoCodeName);
    return response.changes > 0;
}
async function claimPromoCode(promoCodeName, claimedUserIds) {
    const response = runPromise("UPDATE promocodes SET claimedUserIds = (?) WHERE promoCodeName = (?);", claimedUserIds.toString(), promoCodeName);
    return response.changes > 0;
}
async function checkIfOkDailyspin(userId){
    const response = await getPromise("SELECT dailyspin FROM cooldowns WHERE userId = (?);", userId);
    if(Date.now() - 86400000 <= response.dailyspin){return false}else if(Date.now() - 86400000 >= response.dailyspin){return true}else{return true}
}
async function checkIfOkweeklyclaim(userId){
    const response = await getPromise("SELECT weeklyclaim FROM cooldowns WHERE userId = (?);", userId);
    if(Date.now() - 86400000 * 7 <= response.weeklyclaim){return false}else if(Date.now() - 86400000 * 7 >= response.weeklyclaim){return true}else{return true}
}
async function removeBotTrades(userId, botTrades) {
    const response = runPromise("UPDATE wallets SET botTrades = bottrades - (?) WHERE userId = (?);", botTrades.toString(), userId);
    return response.changes > 0;
}
async function removeLtmPoints(userId, ltmPoints) {
    const response = runPromise("UPDATE wallets SET ltmPoints = ltmPoints - (?) WHERE userId = (?);", ltmPoints.toString(), userId);
    return response.changes > 0;
}
async function removeCoins(userId, coins) {
    const response = runPromise("UPDATE wallets SET coins = coins - (?) WHERE userId = (?);", coins.toString(), userId);
    return response.changes > 0;
}
async function getCoins(user) {
    const response = await getPromise("SELECT coins FROM wallets WHERE userId = (?);", user);
    return response?.coins;  
}
async function getPlayerPicks(user) {
    const response = await getPromise("SELECT playerPicks FROM wallets WHERE userId = (?);", user);
    return response?.playerPicks;  
}
async function getPromoCodeData(promoCodeName) {
    const response = await getPromise("SELECT * FROM promocodes WHERE promoCodeName = (?);", promoCodeName);
    return response;  
}async function getTop5Coins() {
    try {
      const response = await getPromiseLB("SELECT userId, coins FROM wallets ORDER BY coins DESC LIMIT 5;");
      const topCoins = response.map((row, index) => `${index + 1}. ${row.userId} - ${row.coins} coins`);
      return topCoins.join('\n');
    } catch (error) {
      console.error("Error fetching top 5:", error);
      return null;
    }
  }
async function getTop5BotTrades(userId) {
    try {
        const response = await getPromiseLB("SELECT userId, botTrades FROM wallets ORDER BY botTrades DESC LIMIT 5;");
        const topTrades = response.map((row, index) => `${index + 1}. ${row.userId} - ${row.botTrades} bot trades`);
        return topTrades.join('\n');
    } catch (error) {
        console.error("Error fetching top 5:", error);
        return null;
    }
}
async function getBotTrades(user) {
    const response = await getPromise("SELECT botTrades FROM wallets WHERE userId = (?);", user);
    return response?.botTrades;  
}
async function getLTMPoints(user) {
    const response = await getPromise("SELECT ltmPoints FROM wallets WHERE userId = (?);", user);
    return response?.ltmPoints;  
}
async function getCards(user) {
    const response = await getPromise("SELECT cardIds FROM wallets WHERE userId = (?);", user);
    return response?.cardIds;  
}
async function checkIfLinked(userId) {
    const response = await getPromise("SELECT userId FROM users WHERE userId = (?);", userId);
    if(response.userId){return true}else{return false};  
}

export { createUser, fetchmfUserByDiscordID, addBotTrades, addLtmPoints, addCooldownevent, addCooldownweeklyclaim, addPlayerPicks, checkIfLinked,
    addCooldownDailySpin,
    getPromoCodeData,
    claimPromoCode,
    addCoins,
    removeBotTrades,
    createPromoCode,
    addUses,
    addClaimedPromoCodeByUserId,
    removeLtmPoints,
    addCards,
    getCards,
    removeCoins,
    getCoins,
    getPlayerPicks,
    getBotTrades,
    getTop5BotTrades,
    getTop5Coins,
    checkIfOkDailyspin,
    checkIfOkweeklyclaim,
    deleteUsername, getLTMPoints
}
