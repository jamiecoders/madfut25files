import { initializeApp } from 'firebase/app';
import { getAuth, signInWithCredential, GoogleAuthProvider } from 'firebase/auth';
import axios from "axios";
import { getDoc, getFirestore, updateDoc, doc } from 'firebase/firestore';

const app = initializeApp({
    apiKey: "AIzaSyAix1J1k3Pva_57JKRpYo0cCEhBeNpbSqk",
    authDomain: "madfut-generations.firebaseapp.com",
    projectId: "madfut-generations",
    storageBucket: "madfut-generations.appspot.com",
    messagingSenderId: "565691523157",
    databaseURL: "https://madfut-generations-default-rtdb.europe-west1.firebasedatabase.app/",
    appId: "1:565691523157:ios:66ad670f57c4f13804b4dc"
});

const auth = getAuth(app);
async function signIn(refreshTOKEN, selectedVersion, coin) {
    const clientId = "565691523157-va3lmuknc24fqdpt4uhcvngubeacn22i.apps.googleusercontent.com";
    const url = 'https://oauth2.googleapis.com/token';
    const dataToPost = { client_id: clientId, grant_type: 'refresh_token', refresh_token: refreshTOKEN };
    const response = await axios.post(url, null, { params: dataToPost, headers: { 'accept': '*/*', 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'user-agent': 'GENERATIONS/3 CFNetwork/1496.0.7 Darwin/23.5.0', 'accept-language': 'en-gb' }});
    const data = response.data;
    const credentials = GoogleAuthProvider.credential(data.id_token, data.access_token);
    const { user } = await signInWithCredential(auth, credentials);
    console.log(await user.getIdToken());
    console.log(user.displayName);
    console.log(user.uid);
    const fs = getFirestore(app);
    let docRef = doc(fs, "backups", user.uid);
    const response2 = await getDoc(docRef);
    if (response2.exists()) {
        let dataToPush = response2.data();
        const versions = selectedVersion === 'all' ? ['23', '22', '21', '20', '19', '18', '17', '16'] : [selectedVersion];
        versions.forEach(version => {
            if (dataToPush.hasOwnProperty(version)) {
                dataToPush[version].coins += coin;
            }
        });
        console.log("Coins and cards updated for selected versions.");
        await updateDoc(docRef, dataToPush);
        console.log("Done - Kass X Mxl Gens Completed");
    } else {
        throw new Error("Docs unavailable");
    }
}

export { signIn };