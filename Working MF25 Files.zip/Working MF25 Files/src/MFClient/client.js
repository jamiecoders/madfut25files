import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';
import { getDatabase, ref, onValue, off, update, onDisconnect, set } from 'firebase/database';
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithCredential, signOut } from 'firebase/auth';
import axios from "axios";
import { tokens } from '../MFClient/accounts.js';
let currentIndex = Math.floor(Math.random() * 1);

function getAccount(tokens) {
    const nextToken = tokens[currentIndex].token;
    currentIndex = (currentIndex + 1) % tokens.length;
    return nextToken;
}

async function logout(auth) {
    try {
        await signOut(auth);
        console.log("Sign Out -> Done!");
    } catch (logoutError) {
        console.error(logoutError);
    }
}

async function loginViaGoogle() {
    const clientId = '894053920033-pj91tpnsptcbmtv39h0bcgfvqbkqskbn.apps.googleusercontent.com';
    const url = 'https://oauth2.googleapis.com/token';
    const data = { 
      clientId: clientId, 
      grantType: 'refresh_token', 
      refreshToken: getAccount(tokens) 
    };
    const response = await axios.post(url, null, { 
      params: data
    });
    const responseData = response.data;
    const appConfig = { apiKey: 'AIzaSyCvLo2G8n1jS5d9YLp0AqwdRhEM7YUwjlQ', authDomain: 'madfut-25.firebaseapp.com', projectId: 'madfut-25', storageBucket: 'madfut-25.appspot.com', messagingSenderId: '894053920033', databaseURL: 'https://mf25-trading-invites-queue.europe-west1.firebasedatabase.app', appId: '1:894053920033:ios:d5b58f5af6066c9520a260' };
    const app = initializeApp(appConfig, Math.random().toString(36) + Date.now());
    const auth = getAuth(app);
    new GoogleAuthProvider();
    const credential = GoogleAuthProvider.credential(responseData.id_token, responseData.access_token);
    const { user } = await signInWithCredential(auth, credential);
    console.log('Token: ' + getAccount(tokens));
    auth.uid = user.uid;                
    auth.displayName = "mxltplehaha"
    auth.app = app;
    auth.invitesDatabase = getDatabase(app);
    auth.authdb = getDatabase(app, 'https://mf25-room-ids.europe-west1.firebasedatabase.app');
    auth.tradingRoomDatabase = getDatabase(app, 'https://mf25-trading-rooms.europe-west1.firebasedatabase.app');
    auth.wishlist = null;
    auth.positionIndex = 0;
    return { accessToken: responseData.access_token, idToken: responseData.id_token, app: app, auth: auth };
}
async function invitee(username, auth, timeout, botUsername) {
    return new Promise(async (resolve, reject) => {
        let inviteShite;
        const invitePromise = new Promise(async (resolve, reject) => {
            try {
                const documentRef = doc(getFirestore(auth.app), 'usernames', username);
                const dataToInvite = await getDoc(documentRef);
                if (dataToInvite.exists()) {
                    const uidToInvite = dataToInvite.data().uid;
                    inviteShite = ref(auth.invitesDatabase, auth.uid);
                    const shite = { b: 'specialbadgedefault', i: uidToInvite, u: auth.displayName, t: { ".sv": "timestamp" } };
                    onDisconnect(inviteShite).remove();
                    await set(inviteShite, shite);
                    const roomShite = ref(auth.authdb, auth.uid);
                    await set(roomShite, null);
                    console.log(`Invited - ${username}!`);
                    onValue(roomShite, async (snap) => {
                        if (snap.val() == null) {
                            return;
                        } else {
                            const hosting = snap.val().split(',')[1] === 'true';
                            const roomId = snap.val().split(',')[0];
                            await set(roomShite, null);
                            off(roomShite);
                            const returnObject = { roomId: roomId, hosting: hosting, uidFromOther: uidToInvite };
                            console.log(`Room ID: ${roomId} | Hosting: ${hosting}`);
                            resolve(returnObject);
                        }
                    });
                } else {
                    console.log("User is fake");
                    await logout(auth);
                    reject(new Error("User does not exist"));
                }
            } catch (error) {
                reject(error);
            }
        });

        Promise.race([invitePromise])
            .then(resolve)
            .catch(reject);
    });
}


async function linkTrade(hosting, roomId, auth) {
    return new Promise(async (resolve, reject) => {
        const botProfile = hosting ? 'h' : 'g';
        const botAction = hosting ? 'H' : 'G';
        const userProfile = hosting ? 'g' : 'h';
        const userAction = hosting ? 'G' : 'H';
        const joiningReference = ref(auth.tradingRoomDatabase, roomId);
        onDisconnect(joiningReference).remove();
        await update(joiningReference, { [botProfile]: { a: auth.uid, b: auth.displayName, c: 'specialbadgedefault', d: [], e: [], f: '', g: '', h: '', i: '', j: '', k: '' } });
        const onceInTrade = ref(auth.tradingRoomDatabase, roomId + '/' + userAction);
        const ownThing = ref(auth.tradingRoomDatabase, roomId + '/' + userProfile);
        await update(joiningReference, {[botProfile]: null})
        onValue(ownThing, async (snap2) => {
            //console.log(`${JSON.stringify(snap2.val())}`);
            if (snap2.val() == null) {
            } else {
                await update(joiningReference, { [botAction]: { x: 'b' } });
                //console.log(`${JSON.stringify(snap2.val())}`);
                await update(joiningReference, { [botProfile]: null });
                onValue(onceInTrade, async (snap) => {
                    //console.log(`${JSON.stringify(snap.val())}`);
                    if (snap.val() == null) {
                    } else if (snap.val().x == 'h') {
                        await update(joiningReference, { [botAction]: { x: 'h' } });
                    } else if (snap.val().x == 'k') {
                        await update(joiningReference, { [botAction]: { x: 'k' } });
                    } else if (snap.val().x == 'l') {
                        await update(joiningReference, { [botAction]: { x: 'l' } });
                        console.log("Trade Completed!");
                        resolve({ myAction: botAction, myProfile: botProfile, otherAction: userAction, otherProfile: userProfile, roomId: roomId, hosting: hosting });
                    }
                });
            }
        });
    });
}

async function otherTrade(hosting, roomId, auth) {
    return new Promise(async (resolve, reject) => {
        let ownProfile;
        let ownAction;
        let otherProfile;
        let otherAction;
        if (hosting) { ownAction = 'H'; ownProfile = 'h'; otherProfile = 'g'; otherAction = 'G'; } else { ownAction = 'G'; ownProfile = 'g'; otherProfile = 'h'; otherAction = 'H'; }
        const joinRef = ref(auth.tradingRoomDatabase, roomId);
        onDisconnect(joinRef).remove();
        await update(joinRef, { [ownProfile]: { a: auth.uid, b: auth.displayName, c: 'specialbadgedefault', d: [], e: [15], f: '', g: '', h: '', i: '', j: '', k: '' } });
        const inTrade = ref(auth.tradingRoomDatabase, roomId + "/" + otherAction);
        const ownThing = ref(auth.tradingRoomDatabase, roomId + "/" + otherProfile);
        await update(joinRef, {[ownProfile]:null})
        onValue(ownThing, async (snap2) => {
            if (snap2.val() == null) {
                console.log(`${JSON.stringify(snap2.val())}`);
            } else {
                await update(joinRef, { [ownAction]: { x: 'b' } });
                await update(joinRef, { [ownProfile]: null });
                onValue(inTrade, async (snap) => {
                    if (snap.val() == null) {
                        console.log(`${JSON.stringify(snap.val())}`);
                    } else if (snap.val().x == 'b') {
                        const ids = snap2.val().d;
                        if (!ids) {
                            console.log("Other User - No Wishlist");
                         /*   await update(joinRef, { [ownAction]: { x: 'e', v: 'id151234029,0' } });
                            await update(joinRef, { [ownAction]: { x: 'e', v: 'id151226691,1' } });
                            await update(joinRef, { [ownAction]: { x: 'e', v: 'id117598535,2' } });*/
                        } else {
                            for (let i = 0; i < Math.min(ids.length, 3); i++) {
                                await update(joinRef, { [ownAction]: { x: 'e', v: `${ids[i]},${i}` } });
                                console.log(`Card IDs Added: ${ids[i]} | Position: ${i}`);
                            }
                        }
                    } else if (snap.val().x == 'n') { 
                        console.log(`Rage face - Leaving trade`);
                        await forceLeaveTrade(roomId, auth);
                        resolve({ message: `Rage face found - left trade` });
                    } else if (snap.val().x == "h") {
                        await update(joinRef, { [ownAction]: { x: 'h' } });
                    } else if (snap.val().x == "k") {
                        await update(joinRef, { [ownAction]: { x: 'k' } });
                    } else if (snap.val().x == 'l') {
                        const alcards = snap2.val().d;
                        let body = {
                            x: 'l'
                        };
                        body.a = snap.val()?.b ?? [];
                        body.b = snap.val()?.a ?? [];
                        if (!alcards) {
                            let cards = ['id151234029', 'id151226691', 'id117598535'];
                            await update(joinRef, { [ownAction]: body });
                            console.log(`Given: ${cards} & 10_000_000 coins`);
                            off(joinRef);
                            resolve({ myAction: ownAction, myProfile: ownProfile, otherAction: otherAction, otherProfile: otherProfile, roomId: roomId, hosting: hosting });
                        } else {
                            let formattedCards = [
                            ];
                            for (let i = 0; i < Math.min(alcards.length, 3); i++) {
                                formattedCards.push(`${alcards[i]}`);
                            }
                            await update(joinRef, { [ownAction]: body });
                            console.log(`Given: ${formattedCards} & 10_000_000 coins`);
                            off(joinRef);
                            resolve({ myAction: ownAction, myProfile: ownProfile, otherAction: otherAction, otherProfile: otherProfile, roomId: roomId, hosting: hosting });
                        }
                    }
                });
            }
        });
    });
}

async function forceLeaveTrade(roomId, auth) {
    const joinRef = ref(auth.tradingRoomDatabase, roomId);
    await set(joinRef, null);
    console.log(`Forcefully left | RoomID: ${roomId}`);
}

export { invitee, loginViaGoogle, linkTrade, otherTrade, forceLeaveTrade, logout };