import { Client, IntentsBitField, Collection, REST, Routes } from 'discord.js';
import path, { dirname } from 'path';
import { pathToFileURL } from 'url';
import chalk from 'chalk';
import fs from 'fs';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const client = new Client({ 
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent
    ]
});

client.commands = new Collection();

async function loadFiles(dir) {
    const files = await fs.promises.readdir(dir, { withFileTypes: true });
    for (const file of files) {
        const filePath = path.join(dir, file.name);
        if (file.isDirectory()) {
            await loadFiles(filePath);
        } else if (file.name.endsWith('.js')) {
            try {
                const filePathUrl = pathToFileURL(filePath);
                const loadedFile = await import(filePathUrl.href);
                if (loadedFile.default) {
                    const itemName = file.name.replace('.js', '');
                    client.commands.set(itemName.toLowerCase(), loadedFile.default);
                    //console.log(chalk.green(`Loaded: ${itemName}`));
                }
            } catch (error) {
                console.error(chalk.red(`Failed to load ${file.name}:`, error));
            }
        }
    }
}
(async () => {
    try {
        const commandsDir = path.resolve(__dirname, 'src/Discord/commands');
        await loadFiles(commandsDir);
        console.log(chalk.cyan('Fuck kass and MADFUT'));
        const commandData = Array.from(client.commands.values()).map(command => command.data.toJSON());
        const rest = new REST({ version: '10' }).setToken(process.env.MFBotToken);
        await rest.put(Routes.applicationCommands(process.env.ClientID), { body: commandData });
        console.log(chalk.green('Uploaded the commands!'));
    } catch (error) {
        console.error(chalk.red('Error starting bot:', error));
    }
})();

client.once('ready', () => {
    console.log(chalk.bold.green(`${client.user.tag} is online and ready`));
    client.user.setPresence({ activities: [{ name: 'Mxltple Leaks' }] });
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;
    const cmd = client.commands.get(interaction.commandName);
    if (!cmd) {
        console.log(`Command not found: ${interaction.commandName}`);
        return interaction.reply({ content: 'Kass is a nigger', ephemeral: true });
    }
    try {
        await cmd.execute(interaction);
        console.log(error)
    } catch (error) {
        console.error(error);
    }
});
client.login(process.env.MFBotToken);